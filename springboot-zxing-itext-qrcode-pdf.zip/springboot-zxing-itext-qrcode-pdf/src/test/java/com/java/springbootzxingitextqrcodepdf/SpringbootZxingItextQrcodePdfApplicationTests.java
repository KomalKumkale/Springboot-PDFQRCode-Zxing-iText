package com.java.springbootzxingitextqrcodepdf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootZxingItextQrcodePdfApplicationTests {

	@Test
	void contextLoads() {
	}

}
