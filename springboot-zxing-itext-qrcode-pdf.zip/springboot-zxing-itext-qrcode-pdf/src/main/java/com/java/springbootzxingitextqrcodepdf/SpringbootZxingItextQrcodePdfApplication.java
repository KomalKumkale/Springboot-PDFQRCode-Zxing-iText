package com.java.springbootzxingitextqrcodepdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootZxingItextQrcodePdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootZxingItextQrcodePdfApplication.class, args);
	}

}
